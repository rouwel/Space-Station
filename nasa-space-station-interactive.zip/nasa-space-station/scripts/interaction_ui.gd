extends CanvasLayer

var _prompt: Label
var _toast: Label
var _dialog: PanelContainer
var _dialog_title: Label
var _dialog_body: Label
var _toast_timer: Timer

func _ready() -> void:
	_build_ui()

func _build_ui() -> void:
	var root := Control.new()
	root.name = "Overlay"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	var reticle := Label.new()
	reticle.text = "+"
	reticle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reticle.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	reticle.set_anchors_preset(Control.PRESET_CENTER)
	reticle.position = Vector2(-8, -14)
	reticle.size = Vector2(16, 28)
	reticle.add_theme_font_size_override("font_size", 22)
	reticle.add_theme_color_override("font_color", Color(0.72, 0.91, 0.96, 0.9))
	root.add_child(reticle)

	_prompt = Label.new()
	_prompt.name = "PromptLabel"
	_prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_prompt.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_prompt.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_prompt.position = Vector2(-220, -96)
	_prompt.size = Vector2(440, 40)
	_prompt.add_theme_font_size_override("font_size", 18)
	_prompt.add_theme_color_override("font_color", Color(0.9, 0.96, 1.0))
	_prompt.add_theme_color_override("font_shadow_color", Color(0.02, 0.06, 0.09, 0.9))
	_prompt.add_theme_constant_override("shadow_offset_x", 1)
	_prompt.add_theme_constant_override("shadow_offset_y", 1)
	_prompt.visible = false
	root.add_child(_prompt)

	_toast = Label.new()
	_toast.name = "ToastLabel"
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_toast.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	_toast.position = Vector2(-250, -150)
	_toast.size = Vector2(500, 56)
	_toast.add_theme_font_size_override("font_size", 17)
	_toast.add_theme_color_override("font_color", Color(0.82, 0.94, 0.97))
	_toast.visible = false
	root.add_child(_toast)

	_dialog = PanelContainer.new()
	_dialog.name = "InfoPanel"
	_dialog.set_anchors_preset(Control.PRESET_CENTER)
	_dialog.position = Vector2(-250, -150)
	_dialog.size = Vector2(500, 300)
	_dialog.custom_minimum_size = Vector2(500, 300)
	_dialog.visible = false
	root.add_child(_dialog)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 20)
	margin.add_theme_constant_override("margin_bottom", 20)
	_dialog.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 14)
	margin.add_child(column)
	_dialog_title = Label.new()
	_dialog_title.add_theme_font_size_override("font_size", 26)
	_dialog_title.add_theme_color_override("font_color", Color(0.65, 0.88, 0.96))
	column.add_child(_dialog_title)
	_dialog_body = Label.new()
	_dialog_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_dialog_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_dialog_body.add_theme_font_size_override("font_size", 17)
	_dialog_body.add_theme_color_override("font_color", Color(0.91, 0.94, 0.95))
	column.add_child(_dialog_body)
	var close_hint := Label.new()
	close_hint.text = "Press E or Esc to close"
	close_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	close_hint.add_theme_font_size_override("font_size", 13)
	close_hint.add_theme_color_override("font_color", Color(0.58, 0.69, 0.73))
	column.add_child(close_hint)

	_toast_timer = Timer.new()
	_toast_timer.one_shot = true
	_toast_timer.wait_time = 2.6
	_toast_timer.timeout.connect(_hide_toast)
	add_child(_toast_timer)

func set_prompt(text: String) -> void:
	if _prompt == null or _dialog == null:
		return
	_prompt.text = text
	_prompt.visible = not text.is_empty() and not _dialog.visible

func show_info(title: String, body: String) -> void:
	_toast_timer.stop()
	_toast.visible = false
	_dialog_title.text = title
	_dialog_body.text = body
	_dialog.visible = true
	_prompt.visible = false

func show_message(text: String) -> void:
	if _dialog.visible:
		return
	_toast.text = text
	_toast.visible = true
	_toast_timer.start()

func _hide_toast() -> void:
	_toast.visible = false

func _input(event: InputEvent) -> void:
	if _dialog == null or not _dialog.visible:
		return
	if event.is_action_pressed("interact") or event.is_action_pressed("ui_cancel"):
		_dialog.visible = false
		get_viewport().set_input_as_handled()
