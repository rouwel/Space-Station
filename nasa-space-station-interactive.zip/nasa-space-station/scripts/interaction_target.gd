extends Node3D

@export_enum("power_screen", "oxygen", "bed", "cabinet", "container") var interaction_type: String = "power_screen"
@export var display_name: String = "Station equipment"

var is_open := false

func interaction_prompt() -> String:
	match interaction_type:
		"power_screen": return "E  View station power"
		"oxygen": return "E  Check oxygen system"
		"bed": return "E  Rest"
		"cabinet": return "E  Open / close cabinet"
		"container": return "E  Open / close storage"
	return "E  Interact with %s" % display_name

func interact(_actor: Node = null) -> void:
	var ui := _get_ui()
	if ui == null:
		return
	match interaction_type:
		"power_screen":
			ui.show_info("Station power", "STATION POWER: NOMINAL\n\nMain reactor: ONLINE\nLife support: ONLINE\nHabitation: ONLINE\nOxygen systems: ONLINE\n\nThis is a prototype status display.")
		"oxygen":
			ui.show_info("Oxygen system", "OXYGEN SUPPLY: NOMINAL\n\nPrimary tanks: CONNECTED\nPressure: WITHIN OPERATING RANGE\nDistribution: ONLINE")
		"bed":
			ui.show_message("You rest briefly.\nPress E to continue.")
		"cabinet":
			is_open = not is_open
			ui.show_message("Cabinet %s." % ("opened" if is_open else "closed"))
		"container":
			is_open = not is_open
			ui.show_message("Storage container %s." % ("opened" if is_open else "closed"))
		_:
			ui.show_message("%s" % display_name)

func _get_ui() -> Node:
	var scene := get_tree().current_scene
	if scene == null:
		return null
	return scene.get_node_or_null("InteractionUI")
