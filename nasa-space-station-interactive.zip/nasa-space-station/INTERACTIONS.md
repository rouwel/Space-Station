# Station interactions

The project now has a lightweight first-person interaction system.

- Look directly at a prop from within about 3.5 metres to see its prompt.
- Press **E** to interact.
- Press **E** or **Esc** to close the power/oxygen information panel.
- **Esc** also retains the existing mouse-capture toggle when no information panel is open.

Implemented targets: station power display, oxygen tank station, bed, cabinet, and storage container. The power and oxygen panels show prototype status text; the bed provides brief rest feedback. Cabinet and container interactions currently toggle their open/closed state in the prompt feedback, but do not animate the generated one-piece models. Physical sleep progression, inventory, and live power/oxygen simulation are not implemented.

The interaction uses a short raycast from the player camera, so props need a collision body to be targetable. The station builder adds those colliders to the placed interactable props.
